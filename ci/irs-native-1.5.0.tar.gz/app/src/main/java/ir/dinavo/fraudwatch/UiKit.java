package ir.dinavo.fraudwatch;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Typeface;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.text.NumberFormat;
import java.util.Locale;

/** Small native design system: compact surfaces, restrained motion, zero third-party UI dependencies. */
final class UiKit {
    static final int BG=Color.rgb(8,12,18), SURFACE=Color.rgb(15,21,29), SURFACE_2=Color.rgb(20,28,38);
    static final int TEXT=Color.rgb(242,247,250), MUTED=Color.rgb(140,155,173), BORDER=Color.rgb(39,51,66);
    static final int ACCENT=Color.rgb(87,226,190), CYAN=Color.rgb(92,196,255), RED=Color.rgb(255,99,112), AMBER=Color.rgb(255,187,92);

    static int dp(Context c,float v){return Math.round(v*c.getResources().getDisplayMetrics().density);}
    static GradientDrawable round(int color,float radius, int strokeColor, int strokeDp, Context c){
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(c,radius));
        if(strokeDp>0)d.setStroke(dp(c,strokeDp),strokeColor);return d;
    }
    static GradientDrawable round(int color,float radius,Context c){return round(color,radius,Color.TRANSPARENT,0,c);}

    static TextView text(Context c,String s,float size,int color){TextView v=new TextView(c);v.setText(s);v.setTextSize(size);v.setTextColor(color);v.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);v.setTextDirection(View.TEXT_DIRECTION_RTL);v.setLineSpacing(0,1.15f);return v;}
    static TextView title(Context c,String s,float size){TextView v=text(c,s,size,TEXT);v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    static TextView pill(Context c,String s,int color){TextView v=title(c,s,11);v.setTextColor(color);v.setGravity(Gravity.CENTER);v.setPadding(dp(c,10),dp(c,5),dp(c,10),dp(c,5));v.setBackground(round(withAlpha(color,28),99,color,1,c));return v;}

    static EditText input(Context c,String hint,boolean password){EditText e=new EditText(c);e.setHint(hint);e.setTextColor(TEXT);e.setHintTextColor(Color.rgb(104,120,139));e.setTextSize(15);e.setSingleLine(true);e.setTextDirection(View.TEXT_DIRECTION_RTL);e.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);e.setPadding(dp(c,16),0,dp(c,16),0);e.setBackground(round(SURFACE_2,16,BORDER,1,c));if(password)e.setInputType(0x00000081);return e;}
    static Button button(Context c,String label,boolean primary){Button b=new Button(c);b.setText(label);b.setTextSize(14);b.setTextColor(primary?Color.rgb(4,25,22):TEXT);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setMinHeight(0);b.setMinimumHeight(0);b.setPadding(dp(c,16),0,dp(c,16),0);b.setBackground(round(primary?ACCENT:SURFACE_2,15,primary?ACCENT:BORDER,1,c));pressMotion(b,c);return b;}
    static ProgressBar spinner(Context c){ProgressBar p=new ProgressBar(c);p.setIndeterminateTintList(ColorStateList.valueOf(ACCENT));return p;}

    static LinearLayout card(Context c){LinearLayout v=new LinearLayout(c);v.setOrientation(LinearLayout.VERTICAL);v.setPadding(dp(c,16),dp(c,15),dp(c,16),dp(c,15));v.setBackground(round(SURFACE,20,BORDER,1,c));return v;}
    static View spacer(Context c,int h){View v=new View(c);v.setLayoutParams(new LinearLayout.LayoutParams(1,dp(c,h)));return v;}

    static void enter(View v,int order){v.setAlpha(0f);v.setTranslationY(dp(v.getContext(),8));v.animate().alpha(1f).translationY(0).setStartDelay(Math.min(order*28L,180L)).setDuration(220).setInterpolator(new DecelerateInterpolator()).start();}
    static void swap(FrameLayout host,View old,View next){if(old==null){host.addView(next,new FrameLayout.LayoutParams(-1,-1));enter(next,0);return;}next.setAlpha(0f);next.setTranslationX(dp(host.getContext(),8));host.addView(next,new FrameLayout.LayoutParams(-1,-1));next.animate().alpha(1f).translationX(0).setDuration(190).setInterpolator(new DecelerateInterpolator()).start();old.animate().alpha(0f).translationX(-dp(host.getContext(),6)).setDuration(150).setListener(new AnimatorListenerAdapter(){@Override public void onAnimationEnd(Animator animation){host.removeView(old);}}).start();}
    static void count(TextView view,long target,String suffix){ValueAnimator a=ValueAnimator.ofFloat(0f,1f);a.setDuration(620);a.setInterpolator(new DecelerateInterpolator());NumberFormat f=NumberFormat.getIntegerInstance(new Locale("fa"));a.addUpdateListener(x->{long val=(long)(target*(float)x.getAnimatedValue());view.setText(f.format(val)+(suffix==null?"":suffix));});a.start();}
    static void haptic(View v){try{v.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP);}catch(Exception ignored){}}
    static void pressMotion(View v,Context c){v.setOnTouchListener((view,event)->{if(event.getAction()==MotionEvent.ACTION_DOWN){view.animate().scaleX(.975f).scaleY(.975f).setDuration(70).start();}else if(event.getAction()==MotionEvent.ACTION_UP||event.getAction()==MotionEvent.ACTION_CANCEL){view.animate().scaleX(1f).scaleY(1f).setDuration(120).start();if(event.getAction()==MotionEvent.ACTION_UP)haptic(view);}return false;});}
    static int withAlpha(int color,int alpha){return Color.argb(alpha,Color.red(color),Color.green(color),Color.blue(color));}
    static int riskColor(String risk){if("critical".equals(risk))return RED;if("high".equals(risk))return Color.rgb(255,125,90);if("medium".equals(risk))return AMBER;return ACCENT;}
    static String riskLabel(String risk){if("critical".equals(risk))return "بحرانی";if("high".equals(risk))return "ریسک بالا";if("medium".equals(risk))return "متوسط";return "کم";}

    /** Small vector-like icon view. Icons are deliberately quiet and consistent. */
    static final class IconView extends View {
        static final int HOME=1, ALERT=2, SEARCH=3, TEAM=4, MORE=5, BACK=6, CHEVRON=7, SHIELD=8, USER=9, MULTI=10, SEND=11, APP=12, LOG=13;
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);private int kind;private int color=MUTED;
        IconView(Context c,int kind){super(c);this.kind=kind;p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(c,1.8f));p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);setWillNotDraw(false);}
        void setIconColor(int c){color=c;invalidate();}
        @Override protected void onDraw(Canvas c){super.onDraw(c);p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(getContext(),1.8f));float w=getWidth(),h=getHeight(),cx=w/2f,cy=h/2f,s=Math.min(w,h)*.28f;Path q=new Path();
            if(kind==HOME){q.moveTo(cx-s,cy);q.lineTo(cx,cy-s);q.lineTo(cx+s,cy);q.lineTo(cx+s*.8f,cy+s);q.lineTo(cx-s*.8f,cy+s);q.close();c.drawPath(q,p);}
            else if(kind==ALERT){q.moveTo(cx,cy-s*1.2f);q.lineTo(cx+s*1.05f,cy+s);q.lineTo(cx-s*1.05f,cy+s);q.close();c.drawPath(q,p);c.drawLine(cx,cy-s*.45f,cx,cy+s*.25f,p);c.drawPoint(cx,cy+s*.63f,p);}
            else if(kind==SEARCH){c.drawCircle(cx-s*.18f,cy-s*.15f,s*.72f,p);c.drawLine(cx+s*.35f,cy+s*.38f,cx+s,cy+s,p);}
            else if(kind==TEAM){c.drawCircle(cx-s*.45f,cy-s*.45f,s*.42f,p);c.drawCircle(cx+s*.45f,cy-s*.32f,s*.34f,p);c.drawArc(new RectF(cx-s*1.15f,cy-s*.05f,cx+s*.2f,cy+s*1.05f),190,160,false,p);c.drawArc(new RectF(cx,cy+s*.05f,cx+s*1.1f,cy+s*.9f),190,140,false,p);}
            else if(kind==MORE){c.drawCircle(cx-s*.75f,cy,s*.13f,p);c.drawCircle(cx,cy,s*.13f,p);c.drawCircle(cx+s*.75f,cy,s*.13f,p);}
            else if(kind==BACK||kind==CHEVRON){c.drawLine(cx+s*.35f,cy-s*.6f,cx-s*.25f,cy,p);c.drawLine(cx-s*.25f,cy,cx+s*.35f,cy+s*.6f,p);}
            else if(kind==SHIELD){q.moveTo(cx,cy-s*1.15f);q.lineTo(cx+s*.9f,cy-s*.72f);q.lineTo(cx+s*.72f,cy+s*.35f);q.quadTo(cx,cy+s*1.2f,cx-s*.72f,cy+s*.35f);q.lineTo(cx-s*.9f,cy-s*.72f);q.close();c.drawPath(q,p);}
            else if(kind==USER){c.drawCircle(cx,cy-s*.45f,s*.45f,p);c.drawArc(new RectF(cx-s,cy,cx+s,cy+s*1.15f),190,160,false,p);}
            else if(kind==MULTI){c.drawCircle(cx-s*.35f,cy-s*.28f,s*.4f,p);c.drawCircle(cx+s*.42f,cy-s*.2f,s*.32f,p);c.drawArc(new RectF(cx-s,cy,cx+s*.2f,cy+s*.9f),190,160,false,p);}
            else if(kind==SEND){q.moveTo(cx-s,cy-s*.7f);q.lineTo(cx+s,cy);q.lineTo(cx-s,cy+s*.7f);q.lineTo(cx-s*.55f,cy);q.close();c.drawPath(q,p);c.drawLine(cx-s*.55f,cy,cx+s*.45f,cy,p);}
            else if(kind==APP){c.drawRoundRect(new RectF(cx-s*.7f,cy-s*1.05f,cx+s*.7f,cy+s*1.05f),s*.18f,s*.18f,p);c.drawLine(cx-s*.22f,cy+s*.72f,cx+s*.22f,cy+s*.72f,p);}
            else if(kind==LOG){c.drawRoundRect(new RectF(cx-s*.8f,cy-s,cx+s*.8f,cy+s),s*.12f,s*.12f,p);for(int i=-1;i<=1;i++)c.drawLine(cx-s*.48f,cy+i*s*.45f,cx+s*.48f,cy+i*s*.45f,p);}
        }
    }
}
